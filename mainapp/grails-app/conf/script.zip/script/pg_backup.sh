#!/bin/sh
################################
# script by Tajul islam
################################

#Repless your postgresql root username given below
PGUSER=postgres

#Repless your postgresql root password given below
PGPASSWORD=

export PGUSER PGPASSWORD

tdate=`date +On_%d-%b-%Y_at_%T`

# this is backup dir, change it if you want other path to save.
# if this dir is not created, then I will create one for you.
path="/pg_backup"

if [ $# -lt 1 ]

# Check if there is atleast one argument [i.e the database whose dump is to be taken]
#First argument is mandatory - Databse name
#Second argument is optional - Destination path to save dump
then

        echo "Bad Arguments"
        echo "-----------------------------------"
        echo "USAGE : pg_dmp.sh <databasename> [outputfile]"
        echo "-----------------------------------"
        exit 1
else

#if one or more arguments were provided
        if [ $# -ge 2 ]
        #if arguments provided is greater than or equal to 2
        then
		#Comment out the below given file exist check and it's associated messages
		# if you want to run the pg_dmpsh script to run silently. i.e from a cron or at job
		# without any user interaction. Then the output dump file will be rewritten if a file
		# already exists. 
                if [ -f $2  ]
                # if destination file ie argument 2 is already existing
                then
                        #Show confirmation message to confirm whether replace file with new one or exit
                        dialog --title "Confirm File Replace" --backtitle "pg_dmp.sh"\
                        --yesno "\nFile already exist, Do you want to replace it with '$2' file" 7 90
                        sel=$?
                        case $sel in
                        #if Yes then take dump and replace the existing file with new dump
                        0)  pg_dump $1 -f $2 -i -x -O -R;;
                        #if No then exit
                        1) exit 1 ;;
                        #if escape then exit
                        255) exit 1;;
                        esac
                else
                        #if destination file does not exist then create and save the dump in destination path
                         pg_dump $1 -f $2 -i -x -O -R
                fi
        else
                if [ $# -eq 1 ]
                #if arguments provided is equal to 1
                then

			if [ -d $path ]
			then 
				echo "taking backup on " $path/$1
			else 
				mkdir $path
				echo  $path " is created."
			fi


                        if [ -d $path/$1 ]
                        #if folder name pg_backup_'databsename' exist in the current users home directory
                        then    
                                #if destination file does not exist then create and save the dump
                                pg_dump $1 -f $path/$1/$tdate -x -O -R -F t  
				echo "Here is your backup file :  " $path/$1/$tdate
                        else
                                #if folder pg_backup_'databsename' does not exist in the current users home dierectory then
                                #Create a new folder
                                mkdir $path/$1
				echo  $path/$1 " is created."

                                #then create dump and save it
                                pg_dump $1 -f $path/$1/$tdate -x -O -R -F t
                                echo "Here is your backup file :  " $path/$1/$tdate
                        fi
                fi
        fi
        if [ $# -gt 2 ]
        #if arguments passed where greater than 2 then  show message
        then
                echo "Extra Arguments ignored"
        fi
fi

#reset PGUSER and PGPASSWORD
PGUSER=""
PGPASSWORD=""
export PGUSER PGPASSWORD
#End


# restore command will be something like : pg_restore -d newdatabase < arms_14-Oct-2011 
