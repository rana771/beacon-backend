#!/bin/sh

export app_path="/athena/build/mis"
export tc="/athena/apache-tomcat-7.0.67"

echo ""
echo "--------------------------------------------"
echo "Stoping Application Server"
echo "--------------------------------------------"
echo ""

cd $tc/bin/
./catalina.sh stop
killall -9 java

cd $tc/work/
rm -rf Catalina


echo ""
echo "--------------------------------------------"
echo "Running Build Process of  Application"
echo "--------------------------------------------"
echo ""


cd $app_path
svn update
cd $app_path/mainapp
#grails clean
grails war
