#!/bin/sh

export tc="/athena/apache-tomcat-7.0.67"

clear

echo ""
echo "============================================="
echo "Stopping Application server... "
echo ""

cd $tc/bin/
./catalina.sh stop
killall -9 java

cd $tc/work/
rm -rf Catalina

echo ""
echo "... Application Service is down"
echo "--------------------------------------------"
echo ""



echo ""
echo "============================================="
echo "Taking backup of existing system... "

cd $tc/backup/
rm -rf ROOT*
mv $tc/webapps/ROOT* $tc/backup/

echo "... Latest Backup is taken"
echo "--------------------------------------------"
echo ""



echo ""  
echo "============================================="
echo "Now Deploying Updated Systen...."

cd $tc/webapps/
cp /athena/build/mis/mainapp/target/ROOT.war .

echo "... New system is deployed"
echo "--------------------------------------------"

echo ""
echo "============================================="
echo "Starting Application server... "
echo "--------------------------------------------"
echo ""

cd $tc/bin/
./catalina.sh start | tail -f ../logs/catalina.out

echo ""
echo "============================================="
echo "---- Application server is  Started, Enjoy... "
echo "--------------------------------------------"
echo ""
